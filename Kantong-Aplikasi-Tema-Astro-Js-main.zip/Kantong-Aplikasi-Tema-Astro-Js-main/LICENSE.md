Kantong Aplikasi Theme License Agreement
Copyright (c) 2026 Kantong Aplikasi
All Rights Reserved.

Official Contact:
Email: contact@kantongaplikasi.com
Technical Support: support@kantongaplikasi.com
WhatsApp: +62 813-9244-2358

==================================================
FREE PERSONAL LICENSE
==================================================

This theme is provided free of charge for PERSONAL USE ONLY.

Personal use means non-commercial use only and does not include client work, business use, company use, or any form of monetization.

Allowed:
- Personal projects
- Learning purposes
- Personal (non-commercial) websites

Not Allowed:
- Client projects
- Business or company websites
- Revenue-generating websites
- Redistribution of theme files
- Reselling in any form
- Uploading to marketplaces (free or paid)
- Repackaging as starter kits or bundles
- Claiming ownership or authorship

Any commercial, client, or business usage requires a paid license.

==================================================
COMMERCIAL LICENSE – $19
(Single Project / Single Domain)
==================================================

Allowed:
- Use for 1 commercial website
- Use for 1 client project
- Revenue-generating website
- Modification permitted

Not Allowed:
- Multi-domain usage
- Redistribution
- Marketplace upload
- Reselling as standalone template

==================================================
AGENCY LICENSE – $99
(Multi Client Use)
==================================================

Allowed:
- Unlimited client projects
- Multi-domain usage for clients
- Full modification rights

Not Allowed:
- Reselling as template product
- Public redistribution
- Marketplace upload

==================================================
ENTERPRISE LICENSE – $249
(Corporate / Company-Wide Use)
==================================================

Allowed:
- Unlimited internal company use
- Multi-domain deployment under one organization
- Advanced customization rights

Not Allowed:
- Reselling as template
- Public redistribution
- Marketplace upload

==================================================

GENERAL TERMS

1. Ownership of this theme remains with Kantong Aplikasi.
2. Purchasing a license grants usage rights, not ownership.
3. Using the theme in a commercial environment without purchasing a valid license is a violation of this agreement.
4. Violation of these terms results in immediate termination of license rights.
5. No refunds once license is issued.
6. Kantong Aplikasi reserves the right to update license terms at any time.

For licensing inquiries:
contact@kantongaplikasi.com

For technical support:
support@kantongaplikasi.com

WhatsApp:
+62 813-9244-2358
